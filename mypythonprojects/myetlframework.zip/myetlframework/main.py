# from pyetl.conn import conn_etl
from pyetl.runetl import query_etl


# conn_etl()

if __name__ == "__main__":

   
    query_etl()
