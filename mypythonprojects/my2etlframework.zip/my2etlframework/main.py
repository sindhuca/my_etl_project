# from etl2py.readconfig2 import config_read
# from etl2py.condb import connection_db
from etl2py.cur_exe import run_etl
# from etl2py.readcsvfile import read_csvfile




# read_csvfile()
run_etl()
# connection_db()

# config_read()